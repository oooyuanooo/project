# -*- coding: utf-8 -*-
# Import需要的套件
import os
import numpy as np
import cv2
import torch
import torch.nn as nn
import torchvision.transforms as transforms
import pandas as pd
from torch.utils.data import DataLoader, Dataset
import time

# 打印当前使用的设备
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using {device} device")

"""#Read image
利用 OpenCV (cv2) 读入照片存放在 numpy array 中
"""
def readfile(path, label):
    # label 是一个 boolean variable
    image_dir = sorted(os.listdir(path)) # 读取每一个图片的文件名并且进行排序
    x = np.zeros((len(image_dir), 128, 128, 3), dtype=np.uint8)
    y = np.zeros((len(image_dir)), dtype=np.uint8)
    for i, file in enumerate(image_dir):
        img = cv2.imread(os.path.join(path, file)) # imread返回值是一个三维数组 该函数有两个参数，第二个参数默认值为彩色图片 RGB三种色域 三层 初始大小为512*512
        x[i, :, :] = cv2.resize(img,(128, 128))  # 修改每张图片的大小为128*128
        if label:
          y[i] = int(file.split("_")[0]) # y是每一种图片的分类用0-10的数字表示
    if label:   # 区分训练集，验证集和测试集 测试集中没有y
      return x, y
    else:
      return x

# 分別把 training set、validation set、testing set 用 readfile 读进来
workspace_dir = './food11'
path0 = os.path.join(workspace_dir, 'training')
print("Reading data")
train_x, train_y = readfile(path0, True)
print("Size of training data = {}".format(len(train_x)))
val_x, val_y = readfile(os.path.join(workspace_dir, "validation"), True)
print("Size of validation data = {}".format(len(val_x)))
test_x = readfile(os.path.join(workspace_dir, "test"), False)
print("Size of Testing data = {}".format(len(test_x)))

"""# Dataset
在 PyTorch 中，可以利用 torch.utils.data 的 Dataset 及 DataLoader 来"包裝" data，使后续的 training 及 testing 更方便。
"""

# training 時做 data augmentation
train_transform = transforms.Compose([
    transforms.ToPILImage(), # 将张量转为PIL图片，由小数转为0-255之间的像素值
    # transforms.RandomHorizontalFlip(), # 随机左右翻转
    # transforms.RandomRotation(15), # 随机进行图像旋转 -15°到15°
    transforms.ToTensor(),  # 将PIL图片再转为张量
])
# testing 時不需做 data augmentation
test_transform = transforms.Compose([
    transforms.ToPILImage(),                                    
    transforms.ToTensor(),
])
class ImgDataset(Dataset):
    def __init__(self, x, y=None, transform=None): # 因为之前进行过transform
        self.x = x
        # label is required to be a LongTensor
        self.y = y
        if y is not None:
            self.y = torch.LongTensor(y)
        self.transform = transform
    def __len__(self):
        return len(self.x)
    def __getitem__(self, index):
        X = self.x[index]
        if self.transform is not None:
            X = self.transform(X)
        if self.y is not None:
            Y = self.y[index]
            return X, Y
        else:
            return X

batch_size = 128
train_set = ImgDataset(train_x, train_y, train_transform)
val_set = ImgDataset(val_x, val_y, test_transform)
train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(val_set, batch_size=batch_size, shuffle=False)

"""
对输入进行normalization
"""
channel_means = [] # 分别计算三个channel的均值
channel_stds = [] # 分别计算三个channel的标准差
for i, data in enumerate(train_loader): #  data[0] (128,3,128,128)
    m = data[0].mean((0,2,3))
    s = data[0].std((0,2,3))
    channel_means.append(m)
    channel_stds.append(s)

channel_mean = torch.stack(channel_means).mean(0) # 对每一个batch的每一个channel进行计算
channel_std = torch.stack(channel_stds).mean(0)

class Normalize(nn.Module):

     def __init__(self):
         super().__init__()

         self.register_buffer('channel_mean', torch.FloatTensor(channel_mean))
         self.register_buffer('channel_std', torch.FloatTensor(channel_std))

     def forward(self, x):
         normalization = ((x - self.channel_mean[None, :, None, None]) /
                       self.channel_std[None,: , None, None])
         return normalization
normalize_layer = Normalize() # 实例化对象
# 进行正规化
for i, data in enumerate(train_loader):
    data[0] = normalize_layer(data[0])

"""# Model"""
# 此处需要搭建神经网络，定义其中的每一个模块
class Classifier(nn.Module):
    def __init__(self):
        super(Classifier, self).__init__()
        # self.flatten = nn.flatten()
        # torch.nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding)
        # torch.nn.MaxPool2d(kernel_size, stride, padding)
        # input 維度 [3, 128, 128]
        # 搭建神经网络CNN
        self.cnn = nn.Sequential(
                # 定义一个二维的卷积层
                nn.Conv2d(3,64,kernel_size=(3,3),stride=1,padding=1), # 64*128*128
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(kernel_size=2,stride=2), # 64*64*64
                # 按照上述方式再定义几个
                nn.Conv2d(64, 128, kernel_size=(3, 3), stride=1, padding=1), # 128*64*64
                nn.BatchNorm2d(128),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(kernel_size=2, stride=2), # 128*32*32

                nn.Conv2d(128, 256, kernel_size=(3, 3), stride=1, padding=1),  # 256*32*32
                nn.BatchNorm2d(256),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(kernel_size=2, stride=2),  # 256*16*16

                nn.Conv2d(256, 512, kernel_size=(3, 3), stride=1, padding=1),  # 512*16*16
                nn.BatchNorm2d(512),
                nn.ReLU(inplace=True),
                nn.MaxPool2d(kernel_size=2, stride=2),  # 512*8*8

                
           ######这里需要你填充
        )
        # 搭建全连接网络FC
        self.fc = nn.Sequential(
            nn.Linear(512 * 8 * 8, 512 * 8),
            nn.ReLU(),
            nn.Linear(512 * 8, 512),
            nn.ReLU(),
            nn.Linear(512, 11),
         ######这里需要你填充
        )

    def forward(self, x): # 该函数在父类中__call__被调用，因而在创建该类对象的时候会被调用
        out = self.cnn(x) # x是input_feature map
        out = out.view(out.size()[0], -1) # 利用view进行reshape，效果等同于进行flatten
        return self.fc(out)

"""# Training

使用 training set 训练，使用 validation set 找好的参数
"""

model = Classifier().cuda()
loss = nn.CrossEntropyLoss() # 因為、为是 classification task，所以 loss 使用 CrossEntropyLoss
optimizer = torch.optim.Adam(model.parameters(), lr=0.001) # optimizer 使用 Adam优化器
num_epoch = 60

for epoch in range(num_epoch):
    epoch_start_time = time.time()
    train_acc = 0.0
    train_loss = 0.0
    val_acc = 0.0
    val_loss = 0.0

    model.train() # 修改model为训练模式
    for i, data in enumerate(train_loader):
        optimizer.zero_grad() #优化器中的所有参数的梯度张量全为设置为0,防止出现累积问题。因为在pytorch中如果上一次已经对某一个张量计算梯度后，第二次计算出的梯度会进行累加。
        train_pred = model(data[0].cuda()) ## 利用模型计算训练的预测值
        batch_loss = loss(train_pred, data[1].cuda()) ## 计算每一个batch的loss 
        batch_loss.backward() # 进行backpropagation,根据loss值反向计算之前每一步的参数的梯度
        optimizer.step() # 根据优化器，对其中的参数进行更新

        train_acc += np.sum(np.argmax(train_pred.cpu().data.numpy(), axis=1) == data[1].numpy()) # 计算当前模型的准确率
        train_loss += batch_loss.item() # 计算总的loss
    
    model.eval() # 修改model的模式
    with torch.no_grad():
        for i, data in enumerate(val_loader):
            val_pred = model(data[0].cuda())
            batch_loss = loss(val_pred, data[1].cuda())

            val_acc += np.sum(np.argmax(val_pred.cpu().data.numpy(), axis=1) == data[1].numpy())
            val_loss += batch_loss.item()

        #把結果 print 出來
        print('[%03d/%03d] %2.2f sec(s) Train Acc: %3.6f Loss: %3.6f | Val Acc: %3.6f loss: %3.6f' % \
            (epoch + 1, num_epoch, time.time()-epoch_start_time, \
             train_acc/train_set.__len__(), train_loss/train_set.__len__(), val_acc/val_set.__len__(), val_loss/val_set.__len__()))

"""得到好的参数后，使用 training set 和 validation set 共同训练"""

train_val_x = np.concatenate((train_x, val_x), axis=0)  ## 把 training set 和 validation set 中的样本特征值进行拼接
train_val_y = np.concatenate((train_y, val_y), axis=0)  ## 把 training set 和 validation set 中的样本标签进行拼接
train_val_set = ImgDataset(train_val_x, train_val_y, train_transform)  ## 把拼接后的结果重新作为训练数据并且进行augmentation后作为数据集 
train_val_loader = DataLoader(train_val_set, batch_size=batch_size, shuffle=True)  ## 用拼接后的数据集构建DataLoader，划分batch并且进行shuffle

# model_best = Classifier().cuda()  ## 创建一个新的分类器对象
loss = nn.CrossEntropyLoss()   ## 计算交叉熵loss
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)   ## 利用Adam进行梯度更新
num_epoch = 60

for epoch in range(num_epoch):
    epoch_start_time = time.time()
    train_acc = 0.0
    train_loss = 0.0

    model.train()
    for i, data in enumerate(train_val_loader):
        optimizer.zero_grad()
        train_pred = model(data[0].cuda())  ## 利用搭建的模型计算训练后的预测值
        batch_loss = loss(train_pred, data[1].cuda())  ## 计算每一个batch的loss
        batch_loss.backward()  ## 进行back propagation
        optimizer.step()  ## 根据优化器对参数进行更新

        train_acc += np.sum(np.argmax(train_pred.cpu().data.numpy(), axis=1) == data[1].numpy())
        train_loss += batch_loss.item()

    model.eval()
    with torch.no_grad():
        # 打印训练结果
        print('[%03d/%03d] %2.2f sec(s) Train Acc: %3.6f Loss: %3.6f' % \
          (epoch + 1, num_epoch, time.time()-epoch_start_time, \
          train_acc/train_val_set.__len__(), train_loss/train_val_set.__len__()))

# 打印模型架构
print(model.parameters)

# 计算模型中训练的参数
Total_params = 0
Trainable_params = 0
NonTrainable_params = 0

for param in model.parameters():
    mulValue = np.prod(param.size())  # 使用numpy prod接口计算参数数组所有元素之积
    Total_params += mulValue  # 总参数量
    if param.requires_grad:
        Trainable_params += mulValue  # 可训练参数量
    else:
        NonTrainable_params += mulValue  # 非可训练参数量

print(f'Total params: {Total_params}')
print(f'Trainable params: {Trainable_params}')
print(f'Non-trainable params: {NonTrainable_params}')



"""# Testing
利用刚刚 train 好的 model 进行 prediction
"""

test_set = ImgDataset(test_x, transform=test_transform)
test_loader = DataLoader(test_set, batch_size=batch_size, shuffle=False)

model.eval()
prediction = []
with torch.no_grad():
    for i, data in enumerate(test_loader):
        test_pred = model(data.cuda())
        test_label = np.argmax(test_pred.cpu().data.numpy(), axis=1)
        for y in test_label:
            prediction.append(y)

#把結果写入 csv 
with open("predict.csv", 'w') as f:
    f.write('Id,Category\n')
    for i, y in  enumerate(prediction):
        f.write('{},{}\n'.format(i, y))
